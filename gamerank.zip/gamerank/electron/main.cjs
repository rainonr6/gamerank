// GameRank desktop shell (Windows / Linux / macOS).
// Serves the bundled web app from a private app:// scheme, handles gamerank:// deep links
// (the Discord login redirect), and keeps the renderer sandboxed.
const { app, BrowserWindow, Menu, ipcMain, protocol, shell } = require('electron');
const fs = require('node:fs');
const path = require('node:path');

const WEB_DIR = path.join(__dirname, '..', 'web');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/manifest+json',
};

protocol.registerSchemesAsPrivileged([
  { scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true } },
]);

let win = null;
let pendingAuthUrl = null;

function deliverAuth(url) {
  if (!url || !url.startsWith('gamerank://')) return;
  if (win && !win.webContents.isLoading()) {
    win.webContents.send('auth', url);
    if (win.isMinimized()) win.restore();
    win.focus();
  } else {
    pendingAuthUrl = url;
  }
}

function createWindow() {
  win = new BrowserWindow({
    width: 1100,
    height: 760,
    minWidth: 420,
    minHeight: 600,
    backgroundColor: '#0b0b0b',
    title: 'GameRank',
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.loadURL('app://gamerank/index.html');
  win.webContents.on('did-finish-load', () => {
    if (pendingAuthUrl) { const u = pendingAuthUrl; pendingAuthUrl = null; deliverAuth(u); }
  });
  // Never navigate the app window away; open web links in the system browser.
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('app://')) { e.preventDefault(); openSafe(url); } });
  win.webContents.setWindowOpenHandler(({ url }) => { openSafe(url); return { action: 'deny' }; });
  win.on('closed', () => { win = null; });
}

function openSafe(url) {
  if (/^https?:\/\//i.test(url)) shell.openExternal(url);
}

ipcMain.handle('open-external', (_e, url) => { if (typeof url === 'string') openSafe(url); });

// ----- deep links -----
if (process.defaultApp) {
  if (process.argv.length >= 2) app.setAsDefaultProtocolClient('gamerank', process.execPath, [path.resolve(process.argv[1])]);
} else {
  app.setAsDefaultProtocolClient('gamerank');
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', (_e, argv) => {
    deliverAuth(argv.find((a) => a.startsWith('gamerank://')));
  });
  app.on('open-url', (e, url) => { e.preventDefault(); deliverAuth(url); }); // macOS

  app.whenReady().then(() => {
    protocol.handle('app', async (request) => {
      let rel = decodeURIComponent(new URL(request.url).pathname);
      if (rel === '/' || rel === '') rel = '/index.html';
      const file = path.normalize(path.join(WEB_DIR, rel));
      if (!file.startsWith(WEB_DIR + path.sep)) return new Response('Forbidden', { status: 403 });
      try {
        const data = await fs.promises.readFile(file); // asar-aware
        return new Response(data, { headers: { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' } });
      } catch {
        return new Response('Not found', { status: 404 });
      }
    });
    Menu.setApplicationMenu(null);
    createWindow();
    deliverAuth(process.argv.find((a) => a.startsWith('gamerank://'))); // Windows/Linux cold start
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  });
  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
}
