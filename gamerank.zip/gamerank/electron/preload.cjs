const { contextBridge, ipcRenderer } = require('electron');

// The only things the web app can ask the desktop shell to do.
contextBridge.exposeInMainWorld('gamerankDesktop', {
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
  onAuth: (cb) => ipcRenderer.on('auth', (_e, url) => cb(url)),
});
