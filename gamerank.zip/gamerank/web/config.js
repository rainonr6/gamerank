// Build-time settings. For the Android and PC apps set apiUrl to your deployed GameRank server,
// e.g. 'https://gamerank.example.com'. Leave '' when the server itself hosts this page (web version).
// The CI workflow overwrites this file from the GAMERANK_API_URL repository variable.
window.GAMERANK_CONFIG = { apiUrl: '' };
