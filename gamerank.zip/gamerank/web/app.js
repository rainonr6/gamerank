/* GameRank client. Plain JS, no build step, runs in browsers, Capacitor (Android) and Electron (PC).
   All DOM is built with h() which only ever uses textContent, so server data can't inject markup. */
(function () {
  'use strict';

  // ---------- state & storage ----------
  const CFG = Object.assign({ apiUrl: '' }, window.GAMERANK_CONFIG || {});
  const LS = {
    get(k) { try { return localStorage.getItem(k); } catch { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch { /* ignore */ } },
    del(k) { try { localStorage.removeItem(k); } catch { /* ignore */ } },
  };
  const Cap = (window.Capacitor && window.Capacitor.Plugins) || null;
  const Desktop = window.gamerankDesktop || null;
  const isNative = Boolean((window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) || Desktop);

  const S = {
    token: LS.get('gr_token'),
    api: (LS.get('gr_api') ?? CFG.apiUrl ?? '').replace(/\/$/, ''),
    me: null, games: [], config: null,
    badges: { confirm: 0, requests: 0 },
    timer: null,
  };

  // ---------- tiny DOM helpers ----------
  const SVGNS = 'http://www.w3.org/2000/svg';
  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'value') el.value = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat(Infinity)) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }
  function svg(tag, attrs, ...kids) {
    const el = document.createElementNS(SVGNS, tag);
    for (const [k, v] of Object.entries(attrs || {})) el.setAttribute(k, v);
    kids.forEach((k) => el.append(k));
    return el;
  }
  const ICONS = {
    home: 'M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z',
    trophy: 'M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3',
    play: 'M12 8v8M8 12h8M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z',
    users: 'M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M10 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M21 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8',
    user: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8',
  };
  function icon(name) {
    return svg('svg', { viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', 'stroke-width': '2', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' },
      svg('path', { d: ICONS[name] }));
  }
  function logo() {
    return svg('svg', { viewBox: '0 0 512 512' },
      svg('circle', { cx: 256, cy: 256, r: 196, fill: '#107c10', stroke: '#9bf00b', 'stroke-width': 12 }),
      svg('path', { d: 'M150 300l106-118 106 118', fill: 'none', stroke: '#0b0b0b', 'stroke-width': 44, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }),
      svg('path', { d: 'M170 372h172', stroke: '#9bf00b', 'stroke-width': 26, 'stroke-linecap': 'round' }));
  }
  function spark(values) {
    const w = 96, hh = 28;
    if (!values || values.length < 2) return svg('svg', { class: 'spark', viewBox: `0 0 ${w} ${hh}` });
    const min = Math.min(...values), max = Math.max(...values), span = Math.max(1, max - min);
    const pts = values.map((v, i) => `${(i / (values.length - 1) * (w - 4) + 2).toFixed(1)},${(hh - 3 - ((v - min) / span) * (hh - 6)).toFixed(1)}`).join(' ');
    const up = values[values.length - 1] >= values[0];
    return svg('svg', { class: 'spark', viewBox: `0 0 ${w} ${hh}` },
      svg('polyline', { points: pts, fill: 'none', stroke: up ? '#9bf00b' : '#e5484d', 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }));
  }

  // ---------- small components ----------
  const okAvatar = (u) => typeof u === 'string' && u.startsWith('https://cdn.discordapp.com/');
  function avatar(user, size) {
    const cls = 'avatar' + (size ? ' ' + size : '');
    if (user && okAvatar(user.avatar)) return h('img', { class: cls, src: user.avatar, alt: '' });
    return h('div', { class: cls }, ((user && user.username) || '?').trim().charAt(0).toUpperCase());
  }
  const tierBadge = (t) => h('span', { class: 'tier ' + t }, t);
  const gscore = (n) => h('span', { class: 'g' }, h('i', {}, 'G'), String(n));
  const sign = (n) => (n > 0 ? '+' + n : String(n));

  let toastEl = null;
  function toast(msg, isErr) {
    if (toastEl) toastEl.remove();
    toastEl = h('div', { class: 'toast' + (isErr ? ' err' : ''), role: 'status' }, msg);
    document.body.append(toastEl);
    const t = toastEl;
    setTimeout(() => t.remove(), isErr ? 4500 : 2600);
  }
  async function guard(fn) {
    try { return await fn(); } catch (e) { toast(e.message || 'Something went wrong.', true); return undefined; }
  }

  // ---------- API ----------
  async function api(path, { method = 'GET', body } = {}) {
    let res;
    try {
      res = await fetch(S.api + path, {
        method,
        headers: { 'content-type': 'application/json', ...(S.token ? { authorization: 'Bearer ' + S.token } : {}) },
        body: body ? JSON.stringify(body) : undefined,
      });
    } catch {
      throw new Error("Can't reach the GameRank server. Check your connection and the server address.");
    }
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && S.token) { signOut(); throw new Error('Session expired. Please sign in again.'); }
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  }

  // ---------- auth ----------
  function takeToken(url) {
    const m = /[#&?]token=([^&]+)/.exec(url || '');
    if (!m) return false;
    S.token = decodeURIComponent(m[1]);
    LS.set('gr_token', S.token);
    return true;
  }
  function signOut() {
    S.token = null; S.me = null;
    LS.del('gr_token');
    clearInterval(S.timer);
    renderLogin();
  }
  function discordLogin() {
    const redirect = isNative ? 'gamerank://auth' : location.origin + location.pathname;
    const url = `${S.api}/auth/discord?redirect=${encodeURIComponent(redirect)}`;
    if (Cap && Cap.Browser) Cap.Browser.open({ url });
    else if (Desktop) Desktop.openExternal(url);
    else location.href = url;
  }
  if (Cap && Cap.App) {
    Cap.App.addListener('appUrlOpen', (e) => {
      if (takeToken(e.url)) { try { Cap.Browser && Cap.Browser.close(); } catch { /* ignore */ } boot(); }
    });
  }
  if (Desktop && Desktop.onAuth) Desktop.onAuth((url) => { if (takeToken(url)) boot(); });

  // ---------- routing ----------
  const NAV = [
    ['home', 'Home', 'home'], ['ranks', 'Ranks', 'trophy'], ['play', 'Log match', 'play'],
    ['friends', 'Friends', 'users'], ['me', 'Profile', 'user'],
  ];
  let renderToken = 0;
  function go(hash) { if (location.hash === '#' + hash) route(); else location.hash = hash; }
  function currentRoute() {
    const parts = (location.hash.replace(/^#\/?/, '') || 'home').split('/');
    return { name: parts[0], arg: parts[1] };
  }
  async function route() {
    if (!S.me) return;
    const { name, arg } = currentRoute();
    const view = document.getElementById('view');
    if (!view) return;
    const my = ++renderToken;
    document.querySelectorAll('nav.tabs button[data-r]').forEach((b) => {
      const active = b.dataset.r === name || (b.dataset.r === 'me' && (name === 'settings' || (name === 'user' && arg === S.me.id)));
      b.classList.toggle('on', active);
    });
    view.replaceChildren(h('div', { class: 'spin' }));
    const views = { home: viewHome, ranks: viewRanks, play: viewPlay, friends: viewFriends, me: () => viewProfile(S.me.id), user: () => viewProfile(arg), settings: viewSettings };
    try {
      const node = await (views[name] || viewHome)();
      if (my === renderToken) { view.replaceChildren(node); window.scrollTo(0, 0); }
    } catch (e) {
      if (my === renderToken) view.replaceChildren(h('div', { class: 'empty' }, e.message, h('div', {}, h('button', { class: 'btn ghost sm', style: { marginTop: '12px' }, onclick: route }, 'Try again'))));
    }
  }
  window.addEventListener('hashchange', route);

  // ---------- shell ----------
  function renderShell() {
    const app = document.getElementById('app');
    const nav = h('nav', { class: 'tabs' },
      h('div', { class: 'brand side-brand' }, logo(), 'GAMERANK'),
      NAV.map(([r, label, ic]) => h('button', { 'data-r': r, onclick: () => go('/' + r), 'aria-label': label },
        icon(ic), h('span', {}, label), h('span', { class: 'dot', id: 'dot-' + r, style: { display: 'none' } }))));
    app.replaceChildren(h('div', { class: 'shell' },
      nav,
      h('div', { style: { flex: 1, minWidth: 0 } },
        h('header', { class: 'top' }, h('div', { class: 'brand' }, logo(), 'GAMERANK'), h('div', { class: 'spacer' }), gscore(S.me.gamerscore)),
        h('main', { id: 'view' }))));
    updateBadges();
  }
  function updateBadges() {
    const set = (id, n) => { const d = document.getElementById('dot-' + id); if (d) { d.textContent = String(n); d.style.display = n ? '' : 'none'; } };
    set('home', S.badges.confirm);
    set('friends', S.badges.requests);
  }
  async function pollBadges() {
    if (document.hidden || !S.token) return;
    try {
      const [m, f] = await Promise.all([api('/api/matches'), api('/api/friends')]);
      S.badges.confirm = m.filter((x) => x.needsMyConfirm).length;
      S.badges.requests = f.incoming.length;
      updateBadges();
    } catch { /* ignore */ }
  }

  // ---------- login ----------
  function renderLogin(msg) {
    const app = document.getElementById('app');
    const cfg = S.config || {};
    const apiInput = h('input', { type: 'url', placeholder: 'https://your-gamerank-server.com', value: S.api, autocomplete: 'off', autocapitalize: 'off' });
    const nameInput = h('input', { type: 'text', placeholder: 'Pick a gamertag', maxlength: 24, autocomplete: 'off' });
    const applyApi = async () => {
      S.api = apiInput.value.trim().replace(/\/$/, '');
      LS.set('gr_api', S.api);
      await loadConfig();
      renderLogin();
    };
    const needsServer = isNative && !S.api;
    app.replaceChildren(h('div', { class: 'login' }, h('div', { class: 'box' },
      h('div', { class: 'logo' }, logo()),
      h('h1', {}, 'GAMERANK'),
      h('p', {}, 'Rank yourself against your friends in every game.'),
      msg && h('div', { class: 'card', style: { marginBottom: '14px', borderColor: '#5a2326' } }, msg),
      h('div', { class: 'stack' },
        (isNative || !cfg.discord && !cfg.devLogin) && h('div', {},
          h('label', {}, 'Server address'), apiInput,
          h('button', { class: 'btn ghost block', style: { marginTop: '8px' }, onclick: () => guard(applyApi) }, 'Connect')),
        !needsServer && cfg.discord && h('button', { class: 'btn discord block', onclick: discordLogin }, 'Continue with Discord'),
        !needsServer && cfg.devLogin && h('div', {},
          cfg.discord && h('div', { class: 'sep' }, 'or test mode'),
          nameInput,
          h('button', { class: 'btn block', style: { marginTop: '8px' }, onclick: () => guard(async () => {
            const r = await api('/auth/dev', { method: 'POST', body: { username: nameInput.value } });
            S.token = r.token; LS.set('gr_token', S.token); boot();
          }) }, 'Play as guest')),
        !needsServer && !cfg.discord && !cfg.devLogin && h('div', { class: 'empty' }, 'This server has no sign-in method configured.')))));
  }

  // ---------- views ----------
  function matchLine(m) {
    const a = m.a ? m.a.username : '?', b = m.b ? m.b.username : '?';
    const text = m.score === 1 ? `${a} beat ${b}` : m.score === 0 ? `${b} beat ${a}` : `${a} drew with ${b}`;
    return text;
  }
  function matchRow(m, actions) {
    return h('div', { class: 'card row wrap' },
      h('div', { style: { fontSize: '26px' } }, (m.game && m.game.icon) || '🎮'),
      h('div', { class: 'grow', style: { minWidth: '160px' } },
        h('div', {}, matchLine(m)),
        h('div', { class: 'small muted' }, (m.game ? m.game.name : '') + ' · ' + new Date(m.createdAt).toLocaleDateString(),
          m.status === 'confirmed' && m.aDelta != null && h('span', {}, ' · ', h('span', { class: m.aDelta >= 0 ? 'up' : 'down' }, `${m.a.username} ${sign(m.aDelta)}`), ' / ', h('span', { class: m.bDelta >= 0 ? 'up' : 'down' }, `${m.b.username} ${sign(m.bDelta)}`)))),
      actions);
  }

  async function viewHome() {
    const [matches, feed, prof] = await Promise.all([api('/api/matches'), api('/api/feed'), api('/api/users/' + S.me.id)]);
    S.me.gamerscore = prof.gamerscore;
    const need = matches.filter((m) => m.needsMyConfirm);
    const waiting = matches.filter((m) => m.status === 'pending' && m.reportedByMe);
    S.badges.confirm = need.length; updateBadges();
    const decide = (m, yes) => guard(async () => {
      await api(`/api/matches/${m.id}/${yes ? 'confirm' : 'reject'}`, { method: 'POST' });
      toast(yes ? 'Match confirmed. Ratings updated!' : 'Match disputed.');
      const me = await api('/api/me'); S.me = me; route();
    });
    return h('div', {},
      h('div', { class: 'hero' }, avatar(S.me, 'lg'),
        h('div', { class: 'grow' }, h('h1', { class: 'ellipsis' }, S.me.username), h('div', { style: { margin: '4px 0 8px' } }, gscore(prof.gamerscore)),
          h('div', { class: 'small muted' }, 'Friend code ', h('span', { class: 'code', title: 'Tap to copy', onclick: () => copy(S.me.friendCode) }, S.me.friendCode)))),
      h('div', { style: { margin: '14px 0 0' } }, h('button', { class: 'btn block', onclick: () => go('/play') }, 'Log a match')),
      need.length > 0 && h('div', {}, h('h2', {}, 'Needs your confirmation'),
        h('div', { class: 'list' }, need.map((m) => matchRow(m, h('div', { class: 'row' },
          h('button', { class: 'btn sm', onclick: () => decide(m, true) }, 'Confirm'),
          h('button', { class: 'btn ghost sm', onclick: () => decide(m, false) }, 'Dispute')))))),
      waiting.length > 0 && h('div', {}, h('h2', {}, 'Waiting on friends'),
        h('div', { class: 'list' }, waiting.map((m) => matchRow(m, h('button', { class: 'btn ghost sm', onclick: () => guard(async () => { await api(`/api/matches/${m.id}/reject`, { method: 'POST' }); route(); }) }, 'Cancel'))))),
      h('h2', {}, 'Your ranks'),
      prof.ratings.length ? h('div', { class: 'list' }, prof.ratings.map((r) => h('div', { class: 'card row' },
        h('div', { style: { fontSize: '26px' } }, r.game ? r.game.icon : '🎮'),
        h('div', { class: 'grow' }, h('div', {}, r.game ? r.game.name : 'Game'), h('div', { class: 'small muted' }, `${r.wins}W · ${r.losses}L · ${r.draws}D`)),
        spark(r.history), h('div', { class: 'center' }, h('div', { class: 'rating' }, r.rating), tierBadge(r.tier)))))
        : h('div', { class: 'empty' }, 'No ranked games yet. Log your first match against a friend to get a rating.'),
      h('h2', {}, 'Friends activity'),
      feed.length ? h('div', { class: 'list' }, feed.slice(0, 15).map((m) => matchRow(m))) : h('div', { class: 'empty' }, 'Nothing yet. Add friends and play!'));
  }

  function copy(text) {
    const done = () => toast('Copied ' + text);
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(done, () => toast(text));
    else toast(text);
  }

  async function viewRanks() {
    // Open on the game you last picked, else the game you're ranked highest in, else the first game.
    let startGame = LS.get('gr_game');
    if (!startGame || !S.games.some((g) => g.id === startGame)) {
      const prof = await api('/api/users/' + S.me.id);
      startGame = (prof.ratings[0] && prof.ratings[0].game && prof.ratings[0].game.id) || (S.games[0] && S.games[0].id);
    }
    const state = { gameId: startGame, scope: 'friends', guildId: '' };
    const out = h('div', { class: 'list' });
    const chips = h('div', { class: 'chips' });
    const scopes = h('div', { class: 'chips' });
    async function load() {
      chips.replaceChildren(...S.games.map((g) => h('button', { class: 'chip' + (g.id === state.gameId ? ' on' : ''), onclick: () => { state.gameId = g.id; LS.set('gr_game', g.id); load(); } }, g.icon + ' ' + g.name)));
      const sc = [['friends', 'Friends'], ['global', 'Everyone'], ...(S.me.guilds || []).slice(0, 12).map((g) => ['guild:' + g.id, '🟣 ' + g.name])];
      const cur = state.scope === 'guild' ? 'guild:' + state.guildId : state.scope;
      scopes.replaceChildren(...sc.map(([k, label]) => h('button', { class: 'chip' + (k === cur ? ' on' : ''), onclick: () => {
        if (k.startsWith('guild:')) { state.scope = 'guild'; state.guildId = k.slice(6); } else { state.scope = k; state.guildId = ''; }
        load();
      } }, label)));
      await guard(async () => {
        const q = `?gameId=${encodeURIComponent(state.gameId)}&scope=${state.scope}` + (state.guildId ? `&guildId=${encodeURIComponent(state.guildId)}` : '');
        const rows = await api('/api/leaderboard' + q);
        out.replaceChildren(...(rows.length ? rows.map((r) => h('div', { class: 'lb' + (r.isMe ? ' me' : ''), onclick: () => go('/user/' + r.user.id) },
          h('div', { class: 'pos' }, r.rank), avatar(r.user),
          h('div', { class: 'grow' }, h('div', { class: 'ellipsis' }, r.user.username), h('div', { class: 'small muted' }, `${r.wins}W ${r.losses}L ${r.draws}D`)),
          tierBadge(r.tier), h('div', { class: 'rating', style: { minWidth: '52px', textAlign: 'right' } }, r.rating)))
          : [h('div', { class: 'empty' }, 'No ranked players here yet. Be the first: log a match!')]));
      });
    }
    await load();
    return h('div', {}, h('h2', {}, 'Leaderboard'), chips, scopes, h('div', { style: { height: '8px' } }), out);
  }

  async function viewPlay() {
    const [fr] = await Promise.all([api('/api/friends')]);
    const st = { gameId: LS.get('gr_game') || '', opponentId: '', result: '', q: '' };
    const root = h('div');
    function draw() {
      const q = st.q.trim().toLowerCase();
      const list = S.games.filter((g) => !q || g.name.toLowerCase().includes(q));
      const exact = S.games.some((g) => g.name.toLowerCase() === q);
      const search = h('input', { type: 'search', placeholder: 'Search games or add your own', value: st.q, oninput: (e) => { st.q = e.target.value; const pos = e.target.selectionStart; draw(); const n = root.querySelector('input[type=search]'); n.focus(); n.setSelectionRange(pos, pos); } });
      const ready = st.gameId && st.opponentId && st.result;
      root.replaceChildren(
        h('h2', {}, '1 · Game'), search,
        h('div', { class: 'tiles', style: { marginTop: '8px' } },
          list.map((g) => h('div', { class: 'tile' + (g.id === st.gameId ? ' on' : ''), onclick: () => { st.gameId = g.id; LS.set('gr_game', g.id); draw(); } }, h('span', { class: 'em' }, g.icon), g.name)),
          q && !exact && st.q.trim().length >= 2 && h('div', { class: 'tile', onclick: () => guard(async () => {
            const g = await api('/api/games', { method: 'POST', body: { name: st.q.trim() } });
            if (!S.games.some((x) => x.id === g.id)) S.games.push(g);
            st.gameId = g.id; st.q = ''; draw();
          }) }, h('span', { class: 'em' }, '➕'), `Add "${st.q.trim()}"`)),
        h('h2', {}, '2 · Opponent'),
        fr.friends.length ? h('div', { class: 'chips' }, fr.friends.map((f) => h('button', { class: 'chip' + (f.id === st.opponentId ? ' on' : ''), onclick: () => { st.opponentId = f.id; draw(); } }, f.username)))
          : h('div', { class: 'empty' }, 'You need a friend to play against. ', h('a', { href: '#/friends' }, 'Add one')),
        h('h2', {}, '3 · Result (for you)'),
        h('div', { class: 'results' }, [['win', 'WIN'], ['draw', 'DRAW'], ['loss', 'LOSS']].map(([k, label]) => h('div', { class: `res ${k}` + (st.result === k ? ' on' : ''), onclick: () => { st.result = k; draw(); } }, label))),
        h('p', { class: 'small muted' }, 'Your friend confirms the result before ratings change, so nobody can fake a win.'),
        h('button', { class: 'btn block', disabled: !ready, onclick: () => guard(async () => {
          await api('/api/matches', { method: 'POST', body: { gameId: st.gameId, opponentId: st.opponentId, result: st.result } });
          const name = (fr.friends.find((f) => f.id === st.opponentId) || {}).username || 'your friend';
          toast(`Sent to ${name} for confirmation`);
          go('/home');
        }) }, 'Submit match'));
    }
    draw();
    return root;
  }

  async function viewFriends() {
    const f = await api('/api/friends');
    S.badges.requests = f.incoming.length; updateBadges();
    const code = h('input', { type: 'text', placeholder: 'Friend code, e.g. K7M2QX', maxlength: 6, autocapitalize: 'characters', autocomplete: 'off' });
    const act = (fn) => () => guard(async () => { await fn(); route(); });
    const person = (u, right) => h('div', { class: 'card row' }, avatar(u), h('div', { class: 'grow ellipsis', style: { cursor: 'pointer' }, onclick: () => go('/user/' + u.id) }, u.username), right);
    return h('div', {},
      h('h2', {}, 'Add a friend'),
      h('div', { class: 'card' },
        h('div', { class: 'row' }, h('div', { class: 'grow' }, code),
          h('button', { class: 'btn', onclick: () => guard(async () => {
            const r = await api('/api/friends', { method: 'POST', body: { code: code.value } });
            toast(r.status === 'accepted' ? "You're friends now!" : 'Request sent'); route();
          }) }, 'Add')),
        h('div', { class: 'small muted', style: { marginTop: '8px' } }, 'Your code: ', h('span', { class: 'code', onclick: () => copy(S.me.friendCode) }, S.me.friendCode), ' · share it in Discord')),
      f.incoming.length > 0 && h('div', {}, h('h2', {}, 'Requests'),
        h('div', { class: 'list' }, f.incoming.map((u) => person(u, h('div', { class: 'row' },
          h('button', { class: 'btn sm', onclick: act(() => api(`/api/friends/${u.id}/accept`, { method: 'POST' })) }, 'Accept'),
          h('button', { class: 'btn ghost sm', onclick: act(() => api(`/api/friends/${u.id}`, { method: 'DELETE' })) }, 'Decline')))))),
      f.discover.length > 0 && h('div', {}, h('h2', {}, 'From your Discord servers'),
        h('div', { class: 'list' }, f.discover.map((u) => person(u, h('button', { class: 'btn sm', onclick: act(() => api('/api/friends', { method: 'POST', body: { userId: u.id } })) }, 'Add'))))),
      h('h2', {}, `Friends (${f.friends.length})`),
      f.friends.length ? h('div', { class: 'list' }, f.friends.map((u) => person(u, h('button', { class: 'btn ghost sm', onclick: () => { S.me && go('/user/' + u.id); } }, 'View'))))
        : h('div', { class: 'empty' }, 'No friends yet. Share your code or sign in with Discord to find people from your servers.'),
      f.outgoing.length > 0 && h('div', {}, h('h2', {}, 'Sent'),
        h('div', { class: 'list' }, f.outgoing.map((u) => person(u, h('button', { class: 'btn ghost sm', onclick: act(() => api(`/api/friends/${u.id}`, { method: 'DELETE' })) }, 'Cancel'))))));
  }

  async function viewProfile(id) {
    const p = await api('/api/users/' + encodeURIComponent(id));
    const isMe = p.friendStatus === 'self';
    const earned = p.achievements.filter((a) => a.earned).length;
    return h('div', {},
      h('div', { class: 'hero' }, avatar(p, 'lg'),
        h('div', { class: 'grow' }, h('h1', { class: 'ellipsis' }, p.username), h('div', { style: { margin: '4px 0' } }, gscore(p.gamerscore)),
          p.h2h && h('div', { class: 'small muted' }, `Head to head vs you: ${p.h2h.losses}W ${p.h2h.wins}L ${p.h2h.draws}D (their record)`),
          isMe && h('div', { class: 'small muted' }, 'Friend code ', h('span', { class: 'code', onclick: () => copy(p.friendCode) }, p.friendCode))),
        isMe && h('button', { class: 'btn ghost sm', onclick: () => go('/settings') }, 'Settings')),
      !isMe && p.friendStatus === 'none' && h('button', { class: 'btn block', style: { marginTop: '12px' }, onclick: () => guard(async () => { await api('/api/friends', { method: 'POST', body: { userId: p.id } }); toast('Request sent'); route(); }) }, 'Add friend'),
      !isMe && p.friendStatus === 'pending' && h('div', { class: 'empty', style: { marginTop: '12px' } }, 'Friend request pending'),
      h('h2', {}, 'Ranks'),
      p.ratings.length ? h('div', { class: 'list' }, p.ratings.map((r) => h('div', { class: 'card row' },
        h('div', { style: { fontSize: '26px' } }, r.game ? r.game.icon : '🎮'),
        h('div', { class: 'grow' }, h('div', {}, r.game ? r.game.name : 'Game'), h('div', { class: 'small muted' }, `${r.wins}W · ${r.losses}L · ${r.draws}D`)),
        spark(r.history), h('div', { class: 'center' }, h('div', { class: 'rating' }, r.rating), tierBadge(r.tier)))))
        : h('div', { class: 'empty' }, 'No ranked games yet.'),
      h('h2', {}, `Achievements (${earned}/${p.achievements.length})`),
      h('div', { class: 'ach' }, p.achievements.map((a) => h('div', { class: a.earned ? '' : 'locked' },
        h('div', { class: 'medal' }, a.g), h('div', {}, h('div', {}, a.name), h('div', { class: 'small muted' }, a.desc))))));
  }

  async function viewSettings() {
    const me = await api('/api/me');
    S.me = Object.assign(S.me, me);
    const hook = h('input', { type: 'url', placeholder: 'https://discord.com/api/webhooks/…', value: me.webhookUrl, autocomplete: 'off' });
    return h('div', {},
      h('h2', {}, 'Discord match feed'),
      h('div', { class: 'card' },
        h('div', { class: 'small muted' }, 'Paste a Discord channel webhook (Channel settings → Integrations → Webhooks) and GameRank posts your confirmed results there.'),
        h('label', {}, 'Webhook URL'), hook,
        h('button', { class: 'btn', style: { marginTop: '10px' }, onclick: () => guard(async () => { await api('/api/me/settings', { method: 'PUT', body: { webhookUrl: hook.value } }); toast('Saved'); }) }, 'Save')),
      h('h2', {}, 'Account'),
      h('div', { class: 'card' },
        h('div', { class: 'row wrap' },
          h('button', { class: 'btn ghost', onclick: signOut }, 'Sign out'),
          h('button', { class: 'btn danger', onclick: () => {
            if (confirm('Delete your account and all your ratings? This cannot be undone.')) guard(async () => { await api('/api/me', { method: 'DELETE' }); signOut(); });
          } }, 'Delete account')),
        isNative && h('div', { class: 'small muted', style: { marginTop: '10px' } }, 'Server: ' + (S.api || 'not set'))));
  }

  // ---------- boot ----------
  async function loadConfig() {
    try { S.config = await api('/api/config'); } catch (e) { S.config = {}; S.configError = e.message; }
  }
  async function boot() {
    if (location.hash.includes('token=')) {
      takeToken(location.hash);
      history.replaceState(null, '', location.pathname + location.search + '#/home');
    }
    document.getElementById('app').replaceChildren(h('div', { class: 'spin' }));
    await loadConfig();
    if (!S.token) return renderLogin(isNative && !S.api ? null : S.configError);
    try {
      S.me = await api('/api/me');
      S.games = await api('/api/games');
    } catch (e) {
      S.token = null; LS.del('gr_token');
      return renderLogin(e.message);
    }
    renderShell();
    if (!location.hash || location.hash === '#') location.hash = '/home';
    route();
    clearInterval(S.timer);
    S.timer = setInterval(pollBadges, 20000);
    pollBadges();
  }
  boot();
})();
