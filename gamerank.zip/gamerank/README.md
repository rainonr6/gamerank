# GameRank

Rank yourself against your friends in every game. Sign in with Discord, log matches, climb the leaderboards.
Green-and-black, console-style UI. One codebase ships as an **Android app**, a **Windows / Linux / macOS desktop app** and a **web app**.

## What's in it

| Feature | How it works |
|---|---|
| **Discord login** | OAuth2 (`identify` + `guilds`). Your Discord servers become leaderboards and a "find friends" list. |
| **Elo ratings per game** | Everyone starts at 1000. New players move faster (K=40, then 32, then 24). Beating a stronger player pays more. |
| **Rank tiers** | Bronze, Silver, Gold, Platinum, Diamond, Master, Legend. |
| **Match confirmation** | You log a result, your friend confirms it before ratings change. Nobody can fake a win. Either side can dispute. |
| **Leaderboards** | Per game, filtered to Friends, Everyone, or any of your Discord servers. |
| **Gamerscore + achievements** | 11 achievements (streaks, tiers, giant slayer, rivalries...) feeding a Gamerscore. |
| **Profiles** | Rating history sparklines, win/loss/draw, head-to-head vs you. |
| **Friends** | Friend codes, requests, and one-tap adds from shared Discord servers. |
| **Discord match feed** | Paste a channel webhook in Settings; confirmed results post there as embeds. |
| **Discord slash commands** | `/rank [game]` and `/leaderboard game` right inside your server. |
| **20 built-in games + custom** | Add any game by typing its name. |

## Layout

```
server/   API + Discord login + slash commands. Zero dependencies (Node 20+).
web/      The whole UI. Plain HTML/CSS/JS, no build step. Used by every platform.
electron/ Desktop shell (Windows/Linux/macOS), handles the gamerank:// login redirect.
scripts/  Android patching, Discord command registration.
.github/  Cloud builds for the APK and desktop installers.
```

## 1. Run it locally (2 minutes)

```bash
node server/index.js          # http://localhost:3000
```

With no Discord keys configured it starts in **test mode** with guest login, so you can try everything.
Open the page in two browsers (or one normal and one private window), make two guests, add each other with the friend code, and log a match.

```bash
node server/test.js           # 21 automated checks
```

## 2. Set up Discord (for real sign-in)

1. [discord.com/developers/applications](https://discord.com/developers/applications) > **New Application**.
2. **OAuth2** > add redirect: `https://YOUR-SERVER/auth/discord/callback`. Copy the **Client ID** and **Client Secret**.
3. Copy `.env.example` to `.env` and fill in `PUBLIC_URL`, `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`.
4. Start the server: `node --env-file=.env server/index.js` (or `docker compose up -d`).

**Slash commands (optional):** copy the **Public Key** from General Information into `DISCORD_PUBLIC_KEY`, set
**Interactions Endpoint URL** to `https://YOUR-SERVER/discord/interactions`, then run once:

```bash
DISCORD_CLIENT_ID=... DISCORD_BOT_TOKEN=... node scripts/register-discord-commands.mjs
```

Invite the bot with scope `applications.commands`.

## 3. Deploy the server

Any host that runs Docker or Node 20+: `docker compose up -d`. Put HTTPS in front (Caddy, nginx, Cloudflare) and set `TRUST_PROXY=1`.
Data lives in one JSON file (`/data/db.json` in Docker), so **mount a volume and back it up**.

## 4. Build the Android and PC apps

The apps are thin shells around `web/` and talk to your server. The included GitHub Actions workflow builds everything:

1. Push this folder to a GitHub repo.
2. Repo **Settings > Secrets and variables > Actions > Variables** > add `GAMERANK_API_URL` = your server URL.
3. Run the **Build GameRank apps** workflow (Actions tab). Download:
   - `GameRank-android-apk` (debug APK, installable by sideloading)
   - `GameRank-windows` (installer + portable `.exe`), `GameRank-linux` (AppImage), `GameRank-macos` (`.dmg`, unsigned)
4. Push a tag like `v1.0.0` to attach all of them to a GitHub Release.

Or build locally: `npm install`, then `npm run desktop:win` for the PC app, or `npm run android:add && npm run android:apk`
(needs JDK 21 and the Android SDK) for the APK.

## Notes and limits

- **Packaging is untested.** The environment this was created in blocks npm and the Android SDK, so the server (21 automated checks), the web UI (driven end-to-end in headless Chromium) and the Android patch script are tested, but the Capacitor/Electron builds and the CI workflow have not been run. Expect to fix small version or path issues on the first cloud build.
- The Android APK is a **debug** build. For Play Store, add a signing keystore and build `bundleRelease`.
- Desktop installers are **unsigned**, so Windows SmartScreen and macOS Gatekeeper will warn on first run.
- Storage is a single JSON file with a single server process. That is plenty for friend groups; move to Postgres before scaling to thousands of users.
- Matches can only be logged between friends, and only the opponent can confirm, which is the anti-cheat model. Pending matches don't expire yet.
