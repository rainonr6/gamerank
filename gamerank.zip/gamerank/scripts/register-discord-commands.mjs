// One-time: registers /rank and /leaderboard with Discord.
//   DISCORD_CLIENT_ID=... DISCORD_BOT_TOKEN=... node scripts/register-discord-commands.mjs
const { DISCORD_CLIENT_ID, DISCORD_BOT_TOKEN } = process.env;
if (!DISCORD_CLIENT_ID || !DISCORD_BOT_TOKEN) {
  console.error('Set DISCORD_CLIENT_ID and DISCORD_BOT_TOKEN.');
  process.exit(1);
}
const commands = [
  { name: 'rank', description: 'Show your GameRank ratings', options: [{ type: 3, name: 'game', description: 'Game name (optional)', required: false }] },
  { name: 'leaderboard', description: 'Top players for a game (this server only when used in a server)', options: [{ type: 3, name: 'game', description: 'Game name', required: true }] },
];
const res = await fetch(`https://discord.com/api/v10/applications/${DISCORD_CLIENT_ID}/commands`, {
  method: 'PUT',
  headers: { authorization: `Bot ${DISCORD_BOT_TOKEN}`, 'content-type': 'application/json' },
  body: JSON.stringify(commands),
});
console.log(res.status, res.ok ? 'commands registered' : await res.text());
