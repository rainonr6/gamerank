// Run after `cap add android` / `cap sync android`. Idempotent.
//  - registers the gamerank://auth deep link (Discord login returns through it)
//  - makes the system bars match the green/black theme
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve('android/app/src/main');
const manifestPath = path.join(root, 'AndroidManifest.xml');
if (!fs.existsSync(manifestPath)) {
  console.error('android/ not found. Run `npm run android:add` first.');
  process.exit(1);
}

let manifest = fs.readFileSync(manifestPath, 'utf8');
if (!manifest.includes('android:scheme="gamerank"')) {
  const filter = `
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="gamerank" android:host="auth" />
            </intent-filter>
`;
  // append to the first <activity> (MainActivity)
  const idx = manifest.indexOf('</activity>');
  if (idx === -1) throw new Error('Could not find </activity> in AndroidManifest.xml');
  manifest = manifest.slice(0, idx) + filter + '        ' + manifest.slice(idx);
  fs.writeFileSync(manifestPath, manifest);
  console.log('patched AndroidManifest.xml (deep link)');
}

const stylesPath = path.join(root, 'res/values/styles.xml');
if (fs.existsSync(stylesPath)) {
  let styles = fs.readFileSync(stylesPath, 'utf8');
  if (!styles.includes('statusBarColor')) {
    styles = styles.replace(
      /(<style name="AppTheme\.NoActionBar"[^>]*>)/,
      '$1\n        <item name="android:statusBarColor">#0b0b0b</item>\n        <item name="android:navigationBarColor">#0b0b0b</item>\n        <item name="android:windowBackground">#0b0b0b</item>',
    );
    fs.writeFileSync(stylesPath, styles);
    console.log('patched styles.xml (dark system bars)');
  }
}
