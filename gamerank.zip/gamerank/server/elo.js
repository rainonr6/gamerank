// Elo rating + rank tiers + achievements. Pure functions, easy to test.

export const START_RATING = 1000;

export const TIERS = [
  { name: 'Bronze', min: 0 },
  { name: 'Silver', min: 900 },
  { name: 'Gold', min: 1050 },
  { name: 'Platinum', min: 1200 },
  { name: 'Diamond', min: 1350 },
  { name: 'Master', min: 1500 },
  { name: 'Legend', min: 1700 },
];

export function tierFor(rating) {
  let t = TIERS[0];
  for (const tier of TIERS) if (rating >= tier.min) t = tier;
  return t.name;
}

// K-factor is higher for new players so they find their level quickly.
export function kFactor(gamesPlayed) {
  if (gamesPlayed < 10) return 40;
  if (gamesPlayed < 30) return 32;
  return 24;
}

// score: 1 = A won, 0.5 = draw, 0 = A lost
export function eloUpdate(ratingA, gamesA, ratingB, gamesB, score) {
  const expA = 1 / (1 + Math.pow(10, (ratingB - ratingA) / 400));
  const expB = 1 - expA;
  const dA = Math.round(kFactor(gamesA) * (score - expA));
  const dB = Math.round(kFactor(gamesB) * ((1 - score) - expB));
  return { dA, dB };
}

export const ACHIEVEMENTS = [
  { id: 'first_blood', name: 'First Blood', desc: 'Win your first match', g: 10 },
  { id: 'ten_wins', name: 'Double Digits', desc: 'Win 10 matches', g: 25 },
  { id: 'fifty_wins', name: 'Veteran', desc: 'Win 50 matches', g: 75 },
  { id: 'streak3', name: 'Hot Streak', desc: 'Win 3 in a row', g: 20 },
  { id: 'streak5', name: 'Unstoppable', desc: 'Win 5 in a row', g: 40 },
  { id: 'multi', name: 'Jack of All Games', desc: 'Play 3 different games', g: 20 },
  { id: 'gold', name: 'Going Gold', desc: 'Reach Gold in any game', g: 30 },
  { id: 'diamond', name: 'Diamond Hands', desc: 'Reach Diamond in any game', g: 60 },
  { id: 'social', name: 'Squad Up', desc: 'Add 3 friends', g: 15 },
  { id: 'giant_slayer', name: 'Giant Slayer', desc: 'Beat someone rated 150+ above you', g: 35 },
  { id: 'rival', name: 'Rivalry', desc: 'Play the same friend 5 times', g: 15 },
];

export function computeAchievements({ user, matches, ratings, friendCount }) {
  const mine = matches
    .filter((m) => m.status === 'confirmed' && (m.aId === user.id || m.bId === user.id))
    .sort((x, y) => x.createdAt - y.createdAt);
  const won = (m) => (m.aId === user.id ? m.score === 1 : m.score === 0);
  const wins = mine.filter(won).length;
  let best = 0, run = 0;
  for (const m of mine) {
    if (won(m)) { run++; best = Math.max(best, run); } else run = 0;
  }
  const games = new Set(mine.map((m) => m.gameId));
  const maxRating = Math.max(0, ...ratings.map((r) => r.rating));
  const slayer = mine.some((m) => {
    const me = m.aId === user.id ? m.aBefore : m.bBefore;
    const them = m.aId === user.id ? m.bBefore : m.aBefore;
    return won(m) && them - me >= 150;
  });
  const opp = {};
  for (const m of mine) {
    const o = m.aId === user.id ? m.bId : m.aId;
    opp[o] = (opp[o] || 0) + 1;
  }
  const earned = new Set();
  if (wins >= 1) earned.add('first_blood');
  if (wins >= 10) earned.add('ten_wins');
  if (wins >= 50) earned.add('fifty_wins');
  if (best >= 3) earned.add('streak3');
  if (best >= 5) earned.add('streak5');
  if (games.size >= 3) earned.add('multi');
  if (maxRating >= 1050) earned.add('gold');
  if (maxRating >= 1350) earned.add('diamond');
  if (friendCount >= 3) earned.add('social');
  if (slayer) earned.add('giant_slayer');
  if (Object.values(opp).some((n) => n >= 5)) earned.add('rival');
  return ACHIEVEMENTS.map((a) => ({ ...a, earned: earned.has(a.id) }));
}
