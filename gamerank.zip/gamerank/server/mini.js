// Minimal Express-style router on node:http. Zero dependencies.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json', '.txt': 'text/plain; charset=utf-8',
};
const MAX_BODY = 50 * 1024;

function compile(p) {
  if (p instanceof RegExp) return { re: p, keys: [] };
  const keys = [];
  const src = p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/:(\w+)/g, (_m, k) => { keys.push(k); return '([^/]+)'; });
  return { re: new RegExp(`^${src}$`), keys };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error('too large'), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

export function createApp({ trustProxy = false } = {}) {
  const stack = [];
  const app = {
    use(fn) { stack.push({ mw: fn }); },
    static(dir) { stack.push({ mw: staticMw(dir) }); },
  };
  for (const method of ['get', 'post', 'put', 'delete']) {
    app[method] = (p, ...handlers) => stack.push({ method: method.toUpperCase(), ...compile(p), handlers });
  }

  app.handle = async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    req.path = url.pathname;
    req.query = Object.fromEntries(url.searchParams);
    req.params = {};
    req.body = {};
    req.ip = (trustProxy && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress;

    res.status = (n) => { res.statusCode = n; return res; };
    res.json = (obj) => {
      if (res.headersSent) return res;
      res.setHeader('content-type', 'application/json; charset=utf-8');
      res.end(JSON.stringify(obj));
      return res;
    };
    res.send = (text) => { res.setHeader('content-type', 'text/plain; charset=utf-8'); res.end(String(text)); return res; };
    res.redirect = (loc) => { res.statusCode = 302; res.setHeader('location', loc); res.end(); return res; };

    res.setHeader('access-control-allow-origin', '*');
    res.setHeader('access-control-allow-headers', 'authorization, content-type');
    res.setHeader('access-control-allow-methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('x-content-type-options', 'nosniff');
    res.setHeader('referrer-policy', 'no-referrer');
    if (req.method === 'OPTIONS') { res.statusCode = 204; return res.end(); }

    try {
      if (req.method === 'POST' || req.method === 'PUT' || req.method === 'DELETE') {
        const raw = await readBody(req);
        req.rawBody = raw; // needed for Discord signature verification
        if (raw) {
          try { req.body = JSON.parse(raw); } catch { return res.status(400).json({ error: 'Bad JSON.' }); }
        }
      }
      for (const layer of stack) {
        if (res.writableEnded) return;
        if (layer.mw) {
          let proceed = false;
          await layer.mw(req, res, () => { proceed = true; });
          if (!proceed) return;
          continue;
        }
        if (layer.method !== req.method) continue;
        const m = layer.re.exec(req.path);
        if (!m) continue;
        req.params = {};
        layer.keys.forEach((k, i) => { req.params[k] = decodeURIComponent(m[i + 1]); });
        for (const h of layer.handlers) {
          let proceed = false;
          await h(req, res, () => { proceed = true; });
          if (!proceed) return;
        }
        if (!res.writableEnded) res.end();
        return;
      }
      if (!res.writableEnded) res.status(404).json({ error: 'Not found.' });
    } catch (e) {
      if (e.status === 413) return res.status(413).json({ error: 'Request too large.' });
      console.error(e);
      if (!res.headersSent) res.status(500).json({ error: 'Something went wrong.' });
      else res.end();
    }
  };

  app.listen = (port, cb) => http.createServer(app.handle).listen(port, cb);
  return app;
}

function staticMw(dir) {
  const root = path.resolve(dir);
  return (req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    if (req.path.startsWith('/api/') || req.path.startsWith('/auth/')) return next();
    let rel;
    try { rel = decodeURIComponent(req.path); } catch { return next(); }
    let file = path.join(root, rel === '/' ? 'index.html' : rel);
    if (file !== root && !file.startsWith(root + path.sep)) return next(); // path traversal guard
    try {
      if (fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
      const body = fs.readFileSync(file);
      res.setHeader('content-type', MIME[path.extname(file)] || 'application/octet-stream');
      res.setHeader('cache-control', file.endsWith('.html') ? 'no-cache' : 'public, max-age=3600');
      res.end(req.method === 'HEAD' ? undefined : body);
    } catch { next(); }
  };
}
