import { createApp } from './mini.js';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  START_RATING, tierFor, eloUpdate, computeAchievements, ACHIEVEMENTS, TIERS,
} from './elo.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ---------- config ----------
const PORT = Number(process.env.PORT || 3000);
const PUBLIC_URL = (process.env.PUBLIC_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const DISCORD_CLIENT_ID = process.env.DISCORD_CLIENT_ID || '';
const DISCORD_CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET || '';
const DISCORD_ENABLED = Boolean(DISCORD_CLIENT_ID && DISCORD_CLIENT_SECRET);
// Dev login lets you test without Discord. Automatically OFF when Discord is configured
// unless you explicitly set DEV_LOGIN=1.
const DEV_LOGIN = process.env.DEV_LOGIN ? process.env.DEV_LOGIN === '1' : !DISCORD_ENABLED;
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data', 'db.json');
const TOKEN_SECRET = process.env.TOKEN_SECRET || (() => {
  // Stable per-install secret so tokens survive restarts when no env var is set.
  const f = path.join(path.dirname(DATA_FILE), '.secret');
  try { return fs.readFileSync(f, 'utf8'); } catch { /* create */ }
  const s = crypto.randomBytes(32).toString('hex');
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f, s, { mode: 0o600 });
  return s;
})();
const EXTRA_REDIRECTS = (process.env.ALLOWED_REDIRECTS || '').split(',').map((s) => s.trim()).filter(Boolean);

// ---------- tiny JSON database ----------
const DEFAULT_GAMES = [
  ['Fortnite', '🏝️'], ['Valorant', '🎯'], ['Call of Duty', '🔫'], ['Rocket League', '🚗'],
  ['Apex Legends', '🦅'], ['Halo', '🪖'], ['Counter-Strike 2', '💣'], ['League of Legends', '⚔️'],
  ['Overwatch 2', '🛡️'], ['EA Sports FC', '⚽'], ['Super Smash Bros.', '🥊'], ['Mario Kart', '🏁'],
  ['Street Fighter 6', '👊'], ['Tekken 8', '🥋'], ['NBA 2K', '🏀'], ['Madden NFL', '🏈'],
  ['Minecraft', '⛏️'], ['Chess', '♟️'], ['Marvel Rivals', '🦸'], ['Other / Custom', '🎮'],
].map(([name, icon], i) => ({ id: `g${i + 1}`, name, icon, custom: false }));

let db = { users: {}, games: DEFAULT_GAMES, ratings: {}, friends: [], matches: [] };
try {
  db = { ...db, ...JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) };
} catch { /* fresh db */ }
let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    const tmp = DATA_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, DATA_FILE);
  }, 150);
}
export const getDb = () => db; // exposed for tests
export function flush() { clearTimeout(saveTimer); fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true }); fs.writeFileSync(DATA_FILE, JSON.stringify(db)); }

const uid = () => crypto.randomBytes(8).toString('hex');
const now = () => Date.now();

// ---------- tokens (HMAC-signed, no extra deps) ----------
const b64 = (b) => Buffer.from(b).toString('base64url');
function sign(payload, ttlMs) {
  const body = b64(JSON.stringify({ ...payload, exp: now() + ttlMs }));
  const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}
function verify(token) {
  if (typeof token !== 'string') return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const good = crypto.createHmac('sha256', TOKEN_SECRET).update(body).digest('base64url');
  const a = Buffer.from(sig), b = Buffer.from(good);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString());
    return p.exp > now() ? p : null;
  } catch { return null; }
}
const DAY = 86400000;

// ---------- helpers ----------
function newFriendCode() {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  for (;;) {
    let c = '';
    for (let i = 0; i < 6; i++) c += chars[crypto.randomInt(chars.length)];
    if (!Object.values(db.users).some((u) => u.friendCode === c)) return c;
  }
}
const ratingKey = (u, g) => `${u}:${g}`;
function getRating(userId, gameId) {
  const k = ratingKey(userId, gameId);
  if (!db.ratings[k]) {
    db.ratings[k] = { userId, gameId, rating: START_RATING, played: 0, wins: 0, losses: 0, draws: 0, history: [] };
  }
  return db.ratings[k];
}
const userRatings = (userId) => Object.values(db.ratings).filter((r) => r.userId === userId && r.played > 0);

function friendship(a, b) {
  return db.friends.find((f) => (f.a === a && f.b === b) || (f.a === b && f.b === a));
}
const isFriend = (a, b) => friendship(a, b)?.status === 'accepted';
const friendIds = (id) =>
  db.friends.filter((f) => f.status === 'accepted' && (f.a === id || f.b === id)).map((f) => (f.a === id ? f.b : f.a));
const sharesGuild = (a, b) => {
  const ga = new Set((db.users[a]?.guilds || []).map((g) => g.id));
  return (db.users[b]?.guilds || []).some((g) => ga.has(g.id));
};

function publicUser(u) {
  if (!u) return null;
  return { id: u.id, username: u.username, avatar: u.avatar, discord: Boolean(u.discordId) };
}
function gamerscore(user) {
  const matches = db.matches.filter((m) => m.status === 'confirmed' && (m.aId === user.id || m.bId === user.id));
  const wins = matches.filter((m) => (m.aId === user.id ? m.score === 1 : m.score === 0)).length;
  const ach = computeAchievements({ user, matches: db.matches, ratings: userRatings(user.id), friendCount: friendIds(user.id).length });
  return ach.filter((a) => a.earned).reduce((s, a) => s + a.g, 0) + wins * 5 + matches.length;
}

async function postWebhook(user, match) {
  const url = user.webhookUrl;
  if (!url) return;
  const game = db.games.find((g) => g.id === match.gameId);
  const a = db.users[match.aId], b = db.users[match.bId];
  const result = match.score === 0.5 ? 'Draw' : `${match.score === 1 ? a.username : b.username} wins`;
  const fmt = (d) => (d >= 0 ? `+${d}` : `${d}`);
  try {
    await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        username: 'GameRank',
        embeds: [{
          title: `${game?.icon || '🎮'} ${game?.name || 'Match'} — ${result}`,
          color: 0x107c10,
          description: `**${a.username}** ${fmt(match.aDelta)} → ${match.aBefore + match.aDelta}\n**${b.username}** ${fmt(match.bDelta)} → ${match.bBefore + match.bDelta}`,
        }],
      }),
      signal: AbortSignal.timeout(5000),
    });
  } catch { /* webhook is best-effort */ }
}

function validRedirect(r) {
  if (typeof r !== 'string') return false;
  if (r.startsWith('gamerank://')) return true;
  try {
    const u = new URL(r);
    if (u.hostname === 'localhost' || u.hostname === '127.0.0.1') return true;
    if (u.origin === new URL(PUBLIC_URL).origin) return true;
  } catch { return false; }
  return EXTRA_REDIRECTS.some((e) => r.startsWith(e));
}
function withToken(redirect, token) {
  const sep = redirect.includes('#') ? '&' : '#';
  return `${redirect}${sep}token=${encodeURIComponent(token)}`;
}

// ---------- app ----------
export const app = createApp({ trustProxy: process.env.TRUST_PROXY === '1' });

// naive in-memory rate limit: 120 req/min per IP
const hits = new Map();
app.use((req, res, next) => {
  const k = req.ip, t = Math.floor(now() / 60000);
  const e = hits.get(k);
  if (!e || e.t !== t) hits.set(k, { t, n: 1 });
  else if (++e.n > 120) return res.status(429).json({ error: 'Slow down a little.' });
  if (hits.size > 5000) hits.clear();
  next();
});

app.get('/api/config', (_req, res) => {
  res.json({ discord: DISCORD_ENABLED, devLogin: DEV_LOGIN, tiers: TIERS, achievements: ACHIEVEMENTS });
});

// --- auth ---
app.get('/auth/discord', (req, res) => {
  if (!DISCORD_ENABLED) return res.status(501).send('Discord login is not configured on this server.');
  const redirect = String(req.query.redirect || '');
  if (!validRedirect(redirect)) return res.status(400).send('Bad redirect.');
  const state = sign({ redirect, n: uid() }, 10 * 60000);
  const params = new URLSearchParams({
    client_id: DISCORD_CLIENT_ID,
    redirect_uri: `${PUBLIC_URL}/auth/discord/callback`,
    response_type: 'code',
    scope: 'identify guilds',
    state,
    prompt: 'none',
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params}`);
});

app.get('/auth/discord/callback', async (req, res) => {
  const st = verify(String(req.query.state || ''));
  if (!st) return res.status(400).send('Login expired. Please try again.');
  if (req.query.error || !req.query.code) return res.redirect(st.redirect);
  try {
    const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: DISCORD_CLIENT_ID,
        client_secret: DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code',
        code: String(req.query.code),
        redirect_uri: `${PUBLIC_URL}/auth/discord/callback`,
      }),
    });
    if (!tokenRes.ok) throw new Error('token exchange failed');
    const { access_token } = await tokenRes.json();
    const h = { authorization: `Bearer ${access_token}` };
    const me = await (await fetch('https://discord.com/api/users/@me', { headers: h })).json();
    const guilds = await (await fetch('https://discord.com/api/users/@me/guilds', { headers: h })).json();
    let user = Object.values(db.users).find((u) => u.discordId === me.id);
    if (!user) {
      user = { id: uid(), discordId: me.id, createdAt: now(), friendCode: newFriendCode(), webhookUrl: '' };
      db.users[user.id] = user;
    }
    user.username = me.global_name || me.username;
    user.avatar = me.avatar ? `https://cdn.discordapp.com/avatars/${me.id}/${me.avatar}.png?size=128` : '';
    user.guilds = Array.isArray(guilds) ? guilds.slice(0, 200).map((g) => ({ id: g.id, name: g.name })) : [];
    save();
    res.redirect(withToken(st.redirect, sign({ uid: user.id }, 30 * DAY)));
  } catch (e) {
    console.error('discord auth error', e.message);
    res.status(502).send('Discord login failed. Please try again.');
  }
});

app.post('/auth/dev', (req, res) => {
  if (!DEV_LOGIN) return res.status(403).json({ error: 'Dev login disabled.' });
  const username = String(req.body?.username || '').trim().slice(0, 24);
  if (!/^[\w .-]{2,24}$/.test(username)) return res.status(400).json({ error: 'Pick a name (2-24 letters/numbers).' });
  let user = Object.values(db.users).find((u) => !u.discordId && u.username.toLowerCase() === username.toLowerCase());
  if (!user) {
    user = { id: uid(), discordId: null, username, avatar: '', createdAt: now(), friendCode: newFriendCode(), guilds: [], webhookUrl: '' };
    db.users[user.id] = user;
    save();
  }
  res.json({ token: sign({ uid: user.id }, 30 * DAY) });
});

function auth(req, res, next) {
  const t = (req.headers.authorization || '').replace(/^Bearer /, '');
  const p = verify(t);
  if (!p || !db.users[p.uid]) return res.status(401).json({ error: 'Not signed in.' });
  req.user = db.users[p.uid];
  next();
}

// --- me ---
app.get('/api/me', auth, (req, res) => {
  const u = req.user;
  res.json({
    ...publicUser(u),
    friendCode: u.friendCode,
    webhookUrl: u.webhookUrl || '',
    guilds: u.guilds || [],
    gamerscore: gamerscore(u),
  });
});

app.put('/api/me/settings', auth, (req, res) => {
  const w = String(req.body?.webhookUrl ?? '').trim();
  if (w && !/^https:\/\/(discord|discordapp)\.com\/api\/webhooks\/\d+\/[\w-]+$/.test(w)) {
    return res.status(400).json({ error: 'That doesn\'t look like a Discord webhook URL.' });
  }
  req.user.webhookUrl = w;
  save();
  res.json({ ok: true });
});

app.delete('/api/me', auth, (req, res) => {
  const id = req.user.id;
  delete db.users[id];
  db.friends = db.friends.filter((f) => f.a !== id && f.b !== id);
  db.matches = db.matches.filter((m) => m.aId !== id && m.bId !== id);
  for (const k of Object.keys(db.ratings)) if (db.ratings[k].userId === id) delete db.ratings[k];
  save();
  res.json({ ok: true });
});

// --- games ---
app.get('/api/games', auth, (_req, res) => res.json(db.games));
app.post('/api/games', auth, (req, res) => {
  const name = String(req.body?.name || '').trim().slice(0, 32);
  if (name.length < 2) return res.status(400).json({ error: 'Game name is too short.' });
  const existing = db.games.find((g) => g.name.toLowerCase() === name.toLowerCase());
  if (existing) return res.json(existing);
  const g = { id: `c${uid()}`, name, icon: '🎮', custom: true };
  db.games.push(g);
  save();
  res.json(g);
});

// --- friends ---
app.get('/api/friends', auth, (req, res) => {
  const me = req.user.id;
  const out = { friends: [], incoming: [], outgoing: [], discover: [] };
  for (const f of db.friends) {
    if (f.a !== me && f.b !== me) continue;
    const other = db.users[f.a === me ? f.b : f.a];
    if (!other) continue;
    if (f.status === 'accepted') out.friends.push(publicUser(other));
    else if (f.from === me) out.outgoing.push(publicUser(other));
    else out.incoming.push(publicUser(other));
  }
  out.discover = Object.values(db.users)
    .filter((u) => u.id !== me && !friendship(me, u.id) && sharesGuild(me, u.id))
    .slice(0, 30)
    .map(publicUser);
  res.json(out);
});

app.post('/api/friends', auth, (req, res) => {
  const me = req.user.id;
  const code = String(req.body?.code || '').trim().toUpperCase();
  const target = req.body?.userId
    ? db.users[req.body.userId]
    : Object.values(db.users).find((u) => u.friendCode === code);
  if (!target) return res.status(404).json({ error: 'No player found with that code.' });
  if (target.id === me) return res.status(400).json({ error: 'That\'s you!' });
  const existing = friendship(me, target.id);
  if (existing) {
    if (existing.status === 'pending' && existing.from !== me) existing.status = 'accepted';
    save();
    return res.json({ ok: true, status: existing.status });
  }
  db.friends.push({ a: me, b: target.id, from: me, status: 'pending', createdAt: now() });
  save();
  res.json({ ok: true, status: 'pending' });
});

app.post('/api/friends/:id/accept', auth, (req, res) => {
  const f = friendship(req.user.id, req.params.id);
  if (!f || f.status !== 'pending' || f.from === req.user.id) return res.status(404).json({ error: 'No request.' });
  f.status = 'accepted';
  save();
  res.json({ ok: true });
});

app.delete('/api/friends/:id', auth, (req, res) => {
  const f = friendship(req.user.id, req.params.id);
  if (f) db.friends.splice(db.friends.indexOf(f), 1);
  save();
  res.json({ ok: true });
});

// --- matches ---
function matchView(m, meId) {
  const a = db.users[m.aId], b = db.users[m.bId];
  const game = db.games.find((g) => g.id === m.gameId);
  return {
    id: m.id, game, a: publicUser(a), b: publicUser(b), score: m.score, status: m.status,
    createdAt: m.createdAt, aDelta: m.aDelta, bDelta: m.bDelta,
    needsMyConfirm: m.status === 'pending' && m.bId === meId,
    reportedByMe: m.aId === meId,
  };
}

app.post('/api/matches', auth, (req, res) => {
  const me = req.user.id;
  const { gameId, opponentId, result } = req.body || {};
  const game = db.games.find((g) => g.id === gameId);
  const score = { win: 1, draw: 0.5, loss: 0 }[result];
  if (!game || score === undefined) return res.status(400).json({ error: 'Pick a game and a result.' });
  if (!db.users[opponentId] || opponentId === me) return res.status(400).json({ error: 'Pick an opponent.' });
  if (!isFriend(me, opponentId)) return res.status(403).json({ error: 'You can only log matches against friends.' });
  const recent = db.matches.filter((m) => m.aId === me && m.bId === opponentId && m.status === 'pending');
  if (recent.length >= 5) return res.status(429).json({ error: 'Too many pending matches with this friend.' });
  const m = { id: uid(), gameId, aId: me, bId: opponentId, score, status: 'pending', createdAt: now() };
  db.matches.push(m);
  save();
  res.json(matchView(m, me));
});

app.post('/api/matches/:id/confirm', auth, async (req, res) => {
  const m = db.matches.find((x) => x.id === req.params.id);
  if (!m || m.bId !== req.user.id || m.status !== 'pending') return res.status(404).json({ error: 'Nothing to confirm.' });
  const ra = getRating(m.aId, m.gameId), rb = getRating(m.bId, m.gameId);
  const { dA, dB } = eloUpdate(ra.rating, ra.played, rb.rating, rb.played, m.score);
  m.aBefore = ra.rating; m.bBefore = rb.rating; m.aDelta = dA; m.bDelta = dB;
  const t = now();
  for (const [r, d, s] of [[ra, dA, m.score], [rb, dB, 1 - m.score]]) {
    r.rating += d; r.played++;
    if (s === 1) r.wins++; else if (s === 0) r.losses++; else r.draws++;
    r.history.push({ t, rating: r.rating });
    if (r.history.length > 100) r.history.shift();
  }
  m.status = 'confirmed';
  m.confirmedAt = t;
  save();
  res.json(matchView(m, req.user.id));
  postWebhook(db.users[m.aId], m);
  if (m.bId !== m.aId) postWebhook(db.users[m.bId], m);
});

app.post('/api/matches/:id/reject', auth, (req, res) => {
  const m = db.matches.find((x) => x.id === req.params.id);
  if (!m || m.status !== 'pending' || (m.bId !== req.user.id && m.aId !== req.user.id)) {
    return res.status(404).json({ error: 'Nothing to reject.' });
  }
  m.status = 'rejected';
  save();
  res.json({ ok: true });
});

app.get('/api/matches', auth, (req, res) => {
  const me = req.user.id;
  const list = db.matches
    .filter((m) => (m.aId === me || m.bId === me) && m.status !== 'rejected')
    .sort((x, y) => y.createdAt - x.createdAt)
    .slice(0, 100)
    .map((m) => matchView(m, me));
  res.json(list);
});

app.get('/api/feed', auth, (req, res) => {
  const ids = new Set([req.user.id, ...friendIds(req.user.id)]);
  const list = db.matches
    .filter((m) => m.status === 'confirmed' && (ids.has(m.aId) || ids.has(m.bId)))
    .sort((x, y) => y.confirmedAt - x.confirmedAt)
    .slice(0, 40)
    .map((m) => matchView(m, req.user.id));
  res.json(list);
});

// --- leaderboard ---
app.get('/api/leaderboard', auth, (req, res) => {
  const me = req.user.id;
  const gameId = String(req.query.gameId || '');
  const scope = String(req.query.scope || 'friends');
  let allowed;
  if (scope === 'friends') allowed = new Set([me, ...friendIds(me)]);
  else if (scope === 'guild') {
    const gid = String(req.query.guildId || '');
    if (!(req.user.guilds || []).some((g) => g.id === gid)) return res.status(403).json({ error: 'You are not in that server.' });
    allowed = new Set(Object.values(db.users).filter((u) => (u.guilds || []).some((g) => g.id === gid)).map((u) => u.id));
  } else allowed = null;
  const rows = Object.values(db.ratings)
    .filter((r) => r.gameId === gameId && r.played > 0 && (!allowed || allowed.has(r.userId)) && db.users[r.userId])
    .sort((x, y) => y.rating - x.rating)
    .slice(0, 100)
    .map((r, i) => ({
      rank: i + 1, user: publicUser(db.users[r.userId]), rating: r.rating, tier: tierFor(r.rating),
      played: r.played, wins: r.wins, losses: r.losses, draws: r.draws, isMe: r.userId === me,
    }));
  res.json(rows);
});

// --- profiles ---
app.get('/api/users/:id', auth, (req, res) => {
  const u = db.users[req.params.id];
  if (!u) return res.status(404).json({ error: 'Player not found.' });
  const ratings = userRatings(u.id).map((r) => ({
    game: db.games.find((g) => g.id === r.gameId),
    rating: r.rating, tier: tierFor(r.rating), played: r.played, wins: r.wins, losses: r.losses, draws: r.draws,
    history: r.history.slice(-30).map((h) => h.rating),
  })).sort((a, b) => b.rating - a.rating);
  const achievements = computeAchievements({ user: u, matches: db.matches, ratings: userRatings(u.id), friendCount: friendIds(u.id).length });
  let h2h = null;
  if (u.id !== req.user.id) {
    const ms = db.matches.filter((m) => m.status === 'confirmed' &&
      ((m.aId === u.id && m.bId === req.user.id) || (m.aId === req.user.id && m.bId === u.id)));
    const mine = (m) => (m.aId === req.user.id ? m.score : 1 - m.score);
    h2h = { wins: ms.filter((m) => mine(m) === 1).length, losses: ms.filter((m) => mine(m) === 0).length, draws: ms.filter((m) => mine(m) === 0.5).length };
  }
  res.json({
    ...publicUser(u), friendCode: u.id === req.user.id ? u.friendCode : undefined,
    gamerscore: gamerscore(u), ratings, achievements, h2h,
    friendStatus: u.id === req.user.id ? 'self' : (friendship(req.user.id, u.id)?.status || 'none'),
  });
});

// --- Discord slash commands (/rank, /leaderboard) via signed interactions ---
const DISCORD_PUBLIC_KEY = process.env.DISCORD_PUBLIC_KEY || '';
const SPKI_ED25519_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');
function verifyDiscordSignature(req) {
  if (!/^[0-9a-f]{64}$/i.test(DISCORD_PUBLIC_KEY)) return false;
  try {
    const key = crypto.createPublicKey({ key: Buffer.concat([SPKI_ED25519_PREFIX, Buffer.from(DISCORD_PUBLIC_KEY, 'hex')]), format: 'der', type: 'spki' });
    const sig = Buffer.from(String(req.headers['x-signature-ed25519'] || ''), 'hex');
    const ts = String(req.headers['x-signature-timestamp'] || '');
    if (Math.abs(Date.now() / 1000 - Number(ts)) > 300) return false; // replay window
    return crypto.verify(null, Buffer.from(ts + (req.rawBody || '')), key, sig);
  } catch { return false; }
}
const md = (s) => String(s).replace(/([\\*_~`|>])/g, '\\$1');
function findGame(q) {
  const s = String(q || '').trim().toLowerCase();
  if (!s) return null;
  return db.games.find((g) => g.name.toLowerCase() === s) || db.games.find((g) => g.name.toLowerCase().includes(s)) || null;
}

app.post('/discord/interactions', (req, res) => {
  if (!verifyDiscordSignature(req)) return res.status(401).send('invalid request signature');
  const i = req.body || {};
  if (i.type === 1) return res.json({ type: 1 }); // PING
  const say = (content) => res.json({ type: 4, data: { content, allowed_mentions: { parse: [] } } });
  if (i.type !== 2) return say('Unsupported interaction.');

  const discordId = (i.member?.user || i.user)?.id;
  const opts = Object.fromEntries((i.data?.options || []).map((o) => [o.name, o.value]));
  const me = Object.values(db.users).find((u) => u.discordId && u.discordId === discordId);

  if (i.data?.name === 'rank') {
    if (!me) return say(`You haven't linked GameRank yet. Sign in with Discord at ${PUBLIC_URL} to start ranking.`);
    let rows = userRatings(me.id).sort((a, b) => b.rating - a.rating);
    if (opts.game) {
      const g = findGame(opts.game);
      if (!g) return say(`I don't know a game called "${md(opts.game)}".`);
      rows = rows.filter((r) => r.gameId === g.id);
      if (!rows.length) return say(`You haven't played ranked ${g.name} yet.`);
    }
    if (!rows.length) return say('No ranked games yet. Log a match in the app!');
    const lines = rows.slice(0, 8).map((r) => {
      const g = db.games.find((x) => x.id === r.gameId);
      return `${g?.icon || '🎮'} **${md(g?.name || 'Game')}** — ${r.rating} (${tierFor(r.rating)}) · ${r.wins}W ${r.losses}L ${r.draws}D`;
    });
    return say(`**${md(me.username)}** · ${gamerscore(me)}G\n${lines.join('\n')}`);
  }

  if (i.data?.name === 'leaderboard') {
    const g = findGame(opts.game);
    if (!g) return say(`I don't know a game called "${md(opts.game || '')}".`);
    const guildId = i.guild_id;
    const inGuild = (u) => (u.guilds || []).some((x) => x.id === guildId);
    const rows = Object.values(db.ratings)
      .filter((r) => r.gameId === g.id && r.played > 0 && db.users[r.userId] && (!guildId || inGuild(db.users[r.userId])))
      .sort((a, b) => b.rating - a.rating).slice(0, 10);
    if (!rows.length) return say(`No ranked ${g.name} players${guildId ? ' in this server' : ''} yet.`);
    const lines = rows.map((r, n) => `${n + 1}. **${md(db.users[r.userId].username)}** — ${r.rating} (${tierFor(r.rating)})`);
    return say(`${g.icon} **${md(g.name)} leaderboard**${guildId ? ' · this server' : ''}\n${lines.join('\n')}`);
  }
  return say('Unknown command.');
});

// --- serve the web build (also the PWA) if present ---
const webDir = path.join(__dirname, '..', 'web');
if (fs.existsSync(webDir)) app.static(webDir);

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  app.listen(PORT, () => {
    console.log(`GameRank server on ${PUBLIC_URL}  (discord: ${DISCORD_ENABLED ? 'on' : 'off'}, dev login: ${DEV_LOGIN ? 'on' : 'off'})`);
  });
  process.on('SIGTERM', () => { flush(); process.exit(0); });
}
