// End-to-end smoke test: spins up the API on a temp database and plays through the main flows.
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gamerank-'));
process.env.DATA_FILE = path.join(dir, 'db.json');
process.env.DEV_LOGIN = '1';
const crypto = await import('node:crypto');
const kp = crypto.generateKeyPairSync('ed25519');
process.env.DISCORD_PUBLIC_KEY = kp.publicKey.export({ type: 'spki', format: 'der' }).subarray(-32).toString('hex');
const { app, flush, getDb } = await import('./index.js');
const { eloUpdate, tierFor } = await import('./elo.js');

const server = app.listen(0);
const base = `http://127.0.0.1:${server.address().port}`;
const call = async (p, { method = 'GET', body, token } = {}) => {
  const r = await fetch(base + p, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: r.status, json: await r.json().catch(() => ({})) };
};
let passed = 0;
const ok = (name, fn) => fn().then(() => { passed++; console.log('  ✓', name); });

// pure Elo
await ok('elo: equal players, winner gains ~20 at K=40', async () => {
  const { dA, dB } = eloUpdate(1000, 0, 1000, 0, 1);
  assert.equal(dA, 20); assert.equal(dB, -20);
});
await ok('elo: upset pays more than expected win', async () => {
  const upset = eloUpdate(1000, 50, 1300, 50, 1).dA;
  const expected = eloUpdate(1300, 50, 1000, 50, 1).dA;
  assert.ok(upset > expected * 3);
});
await ok('tiers map correctly', async () => {
  assert.equal(tierFor(1000), 'Silver'); assert.equal(tierFor(1700), 'Legend'); assert.equal(tierFor(100), 'Bronze');
});

// API flows
const login = async (username) => (await call('/auth/dev', { method: 'POST', body: { username } })).json.token;
const a = await login('Alice'), b = await login('Bob'), c = await login('Cara');

await ok('rejects unauthenticated requests', async () => {
  assert.equal((await call('/api/me')).status, 401);
});
await ok('rejects tampered token', async () => {
  assert.equal((await call('/api/me', { token: a.slice(0, -2) + 'xx' })).status, 401);
});
const meA = (await call('/api/me', { token: a })).json;
const meB = (await call('/api/me', { token: b })).json;
const games = (await call('/api/games', { token: a })).json;

await ok('cannot log a match vs a non-friend', async () => {
  const r = await call('/api/matches', { method: 'POST', token: a, body: { gameId: games[0].id, opponentId: meB.id, result: 'win' } });
  assert.equal(r.status, 403);
});
await ok('friend request by code + accept', async () => {
  assert.equal((await call('/api/friends', { method: 'POST', token: a, body: { code: meB.friendCode } })).json.status, 'pending');
  assert.equal((await call('/api/friends', { token: b })).json.incoming.length, 1);
  assert.equal((await call(`/api/friends/${meA.id}/accept`, { method: 'POST', token: b })).status, 200);
  assert.equal((await call('/api/friends', { token: a })).json.friends.length, 1);
});
let matchId;
await ok('log match -> pending, no rating change yet', async () => {
  const r = await call('/api/matches', { method: 'POST', token: a, body: { gameId: games[0].id, opponentId: meB.id, result: 'win' } });
  assert.equal(r.status, 200); matchId = r.json.id;
  assert.equal((await call(`/api/leaderboard?gameId=${games[0].id}&scope=friends`, { token: a })).json.length, 0);
});
await ok('reporter cannot confirm their own match', async () => {
  assert.equal((await call(`/api/matches/${matchId}/confirm`, { method: 'POST', token: a })).status, 404);
});
await ok('opponent confirms -> Elo applied, leaderboard updates', async () => {
  const r = await call(`/api/matches/${matchId}/confirm`, { method: 'POST', token: b });
  assert.equal(r.json.aDelta, 20); assert.equal(r.json.bDelta, -20);
  const lb = (await call(`/api/leaderboard?gameId=${games[0].id}&scope=friends`, { token: a })).json;
  assert.deepEqual(lb.map((x) => [x.user.username, x.rating]), [['Alice', 1020], ['Bob', 980]]);
});
await ok('confirming twice is rejected', async () => {
  assert.equal((await call(`/api/matches/${matchId}/confirm`, { method: 'POST', token: b })).status, 404);
});
await ok('profile has achievements, head-to-head and gamerscore', async () => {
  const p = (await call(`/api/users/${meB.id}`, { token: a })).json;
  assert.deepEqual(p.h2h, { wins: 1, losses: 0, draws: 0 });
  assert.ok(p.gamerscore >= 0);
  const mine = (await call(`/api/users/${meA.id}`, { token: a })).json;
  assert.ok(mine.achievements.find((x) => x.id === 'first_blood').earned);
});
await ok('non-friend leaderboard hides strangers; global shows them', async () => {
  const friends = (await call(`/api/leaderboard?gameId=${games[0].id}&scope=friends`, { token: c })).json;
  assert.equal(friends.length, 0);
  const global = (await call(`/api/leaderboard?gameId=${games[0].id}&scope=global`, { token: c })).json;
  assert.equal(global.length, 2);
});
await ok('webhook validation', async () => {
  assert.equal((await call('/api/me/settings', { method: 'PUT', token: a, body: { webhookUrl: 'https://evil.example/hook' } })).status, 400);
  assert.equal((await call('/api/me/settings', { method: 'PUT', token: a, body: { webhookUrl: 'https://discord.com/api/webhooks/123/abc-DEF_1' } })).status, 200);
});
await ok('custom games are deduped', async () => {
  const g1 = (await call('/api/games', { method: 'POST', token: a, body: { name: 'Pickleball' } })).json;
  const g2 = (await call('/api/games', { method: 'POST', token: b, body: { name: 'pickleball' } })).json;
  assert.equal(g1.id, g2.id);
});
await ok('open-redirect is blocked', async () => {
  // discord not configured in tests => 501, which still must not redirect anywhere
  const r = await fetch(`${base}/auth/discord?redirect=https://evil.example`, { redirect: 'manual' });
  assert.ok(r.status === 501 || r.status === 400);
});

// ---- Discord slash commands ----
const interact = async (payload, { badSig = false, staleTs = false } = {}) => {
  const body = JSON.stringify(payload);
  const ts = String(Math.floor(Date.now() / 1000) - (staleTs ? 3600 : 0));
  let sig = crypto.sign(null, Buffer.from(ts + body), kp.privateKey).toString('hex');
  if (badSig) sig = sig.replace(/^../, (m) => (m === '00' ? '11' : '00'));
  const r = await fetch(`${base}/discord/interactions`, {
    method: 'POST', body,
    headers: { 'content-type': 'application/json', 'x-signature-ed25519': sig, 'x-signature-timestamp': ts },
  });
  return { status: r.status, text: await r.text() };
};
getDb().users[meA.id].discordId = '1111';
getDb().users[meA.id].guilds = [{ id: 'G1', name: 'Test Server' }];
await ok('discord: signed PING is answered', async () => {
  const r = await interact({ type: 1 });
  assert.equal(r.status, 200); assert.deepEqual(JSON.parse(r.text), { type: 1 });
});
await ok('discord: bad signature and stale timestamp are rejected', async () => {
  assert.equal((await interact({ type: 1 }, { badSig: true })).status, 401);
  assert.equal((await interact({ type: 1 }, { staleTs: true })).status, 401);
});
await ok('discord: /rank shows linked player rating', async () => {
  const r = await interact({ type: 2, data: { name: 'rank', options: [{ name: 'game', value: 'fort' }] }, member: { user: { id: '1111' } } });
  const msg = JSON.parse(r.text).data.content;
  assert.match(msg, /Fortnite/); assert.match(msg, /1020|980/);
});
await ok('discord: /leaderboard is scoped to the server', async () => {
  const inGuild = JSON.parse((await interact({ type: 2, guild_id: 'G1', data: { name: 'leaderboard', options: [{ name: 'game', value: 'Fortnite' }] }, member: { user: { id: '1111' } } })).text).data.content;
  assert.match(inGuild, /Alice/); assert.doesNotMatch(inGuild, /Bob/);
  const other = JSON.parse((await interact({ type: 2, guild_id: 'NOPE', data: { name: 'leaderboard', options: [{ name: 'game', value: 'Fortnite' }] }, member: { user: { id: '1111' } } })).text).data.content;
  assert.match(other, /No ranked/);
});
await ok('discord: unlinked user is told how to link', async () => {
  const msg = JSON.parse((await interact({ type: 2, data: { name: 'rank' }, user: { id: '999' } })).text).data.content;
  assert.match(msg, /linked GameRank/);
});

flush();
server.close();
console.log(`\n${passed} checks passed`);
